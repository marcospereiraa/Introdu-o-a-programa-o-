let mes = parseInt(prompt("digite o número do mes"))

switch (mes){
    case 12:
    case 1:
    case 2:
        console.log("É um mes de verão")

        
break;

case 3:
case 4:
case 5:
console.log("é um mes de outono")
 
break;

case 6:
case 7:
case 8:
    console.log("é um mes de inverno")

    case 9:
    case 10:
    case 11:
    console.log("é um mes de primavera")
    
    break;

    default:
        console.log("DIGITEDE 1 A 12!!!")

    }