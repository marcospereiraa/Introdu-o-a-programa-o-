console.log ((10 > 5) && (5 > 1));
console.log ((4 == 4) && (10 < 5));
console.log (( 3 >= 2) && (2 <= 2));
console.log ((7 != 7) && (5 > 4));
console.log ((8 > 3) && (3 , 10));