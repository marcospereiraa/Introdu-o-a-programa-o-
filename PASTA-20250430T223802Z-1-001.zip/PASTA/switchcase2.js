let lados = parseInt(prompt("Digite a quantidade de lados iguais (0 a 3):"))

switch (lados) {
    case 3:
        console.log("É um triângulo equilátero");
        break;
    case 2:
        console.log("É um triângulo isósceles");
        break;
    case 0:
    case 1:
        console.log("É um triângulo escaleno");
        break;
    default:
        console.log("Digite um valor entre 0 e 3!");
}
